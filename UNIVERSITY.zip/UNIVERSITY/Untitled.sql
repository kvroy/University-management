-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: smvdu
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empl`
--

DROP TABLE IF EXISTS `empl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empl` (
  `empid` varchar(15) NOT NULL,
  `nam` varchar(30) NOT NULL,
  `fnam` varchar(30) NOT NULL,
  `mnam` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `gen` varchar(10) NOT NULL,
  `bldgrp` varchar(35) NOT NULL,
  `doj` varchar(35) NOT NULL,
  `mos` varchar(35) NOT NULL,
  `dsgn` varchar(30) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `adrs` varchar(50) NOT NULL,
  `ct` varchar(30) NOT NULL,
  `stt` varchar(30) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `mbno` varchar(15) NOT NULL,
  `eml` varchar(50) NOT NULL,
  PRIMARY KEY (`empid`),
  UNIQUE KEY `mbno` (`mbno`),
  UNIQUE KEY `eml` (`eml`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empl`
--

LOCK TABLES `empl` WRITE;
/*!40000 ALTER TABLE `empl` DISABLE KEYS */;
INSERT INTO `empl` VALUES ('366363','RAMESH','SURESH','SAUMYA','1991-05-06','Male','AB +ve','2016-12-02','REFERENCE','ASSISTANT PROFESSOR','SCIENCE','ZBBZ','ZBGG','JJJJK','767667','876765645','GJccdcsjh@gmail.com');
/*!40000 ALTER TABLE `empl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `signup` (
  `name` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `UID` varchar(15) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `SECQUE` varchar(60) NOT NULL,
  `SEQANS` varchar(20) NOT NULL,
  PRIMARY KEY (`UID`),
  UNIQUE KEY `EMAIL` (`EMAIL`),
  UNIQUE KEY `MOBILE` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signup`
--

LOCK TABLES `signup` WRITE;
/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` VALUES ('amit001','2020-12-10','amit999','hhjjkk','8877655543','fdsgds@gmail.com','Which is your first school?','jacky'),('dwghj','2020-12-16','dcq','oo','4356','sf@gmail.com','What is your nickname?','fgsg'),('fafgd','2020-12-03','df','mmkk','5234','gdsg','Which is your first school?','dsg'),('sfd','2020-12-22','fdgs','hhgg','87998','dskjhf@yahoo.com','What is your nickname?','sdf'),('ujjwal','2020-12-04','fgkjh','llll','99886','khjsdgk','What is your nickname?','dsab'),('fgdgd','2020-12-09','gdd','gggfff','543456','dfgsgd','Which is your first school?','ggsd'),('fgdgdgsg','2020-12-09','hdd','gggfff','5434566546','dfgsgdgggd','Which is your first school?','ggsdhsg'),('ukfjkjf','2020-12-04','hhhh','llllpp','9988644','khjsdgkfafs','What is your nickname?','dsabkk'),('hfg','2020-12-15','jghf','ppp','8989','hghh','What is your nickname?','hhvbbh'),('sgds','2020-12-10','kkll','kkll','998888','gds','What is your nickname?','ghfs'),('lalit','1997-10-09','lalit','lalit','8888899999','lalit@gmail.com','What is your nickname?','lali'),('SMVDU','1998-09-08','SMVDU','SMVDU','8889996677','SMVDU@SMVDU.COM','What is your nickname?','SMVDU'),('ss','1996-6-8','ttt','ddd','888','hdhfh','dssd','dds'),('ujjwal','2020-12-08','ujjwal','ujjwal','9999000066','dfsg@gmail.com','What is your nickname?','dfg'),('ujjwal','2020-12-09','ujjwal122','lllkkk','455667','jhjghas@GMAIL.COM','Which is your first school?','SDFS');
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stud`
--

DROP TABLE IF EXISTS `stud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stud` (
  `eno` varchar(15) NOT NULL,
  `nam` varchar(30) NOT NULL,
  `fnam` varchar(30) NOT NULL,
  `mnam` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `gen` varchar(10) NOT NULL,
  `bldgrp` varchar(35) NOT NULL,
  `doa` varchar(35) NOT NULL,
  `moa` varchar(35) NOT NULL,
  `crs` varchar(30) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `adrs` varchar(50) NOT NULL,
  `ct` varchar(30) NOT NULL,
  `stt` varchar(30) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `mbno` varchar(15) NOT NULL,
  `eml` varchar(50) NOT NULL,
  PRIMARY KEY (`eno`),
  UNIQUE KEY `mbno` (`mbno`),
  UNIQUE KEY `eml` (`eml`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stud`
--

LOCK TABLES `stud` WRITE;
/*!40000 ALTER TABLE `stud` DISABLE KEYS */;
INSERT INTO `stud` VALUES ('20mms020','hima','ravi','kavi','1998-06-10','Female','A +ve','2020-12-22','GATE','B.TECH','CE','sh65','pune','fjghhvg@gmail.com','654799','8766788700','dsgfs@rediff.com'),('478929879','dsfkfegas','faggaf','fgag','2020-12-10','Female','AB -ve','2019-12-19','MANAGEMENT','BBA','BUSINESS','affg','gfsda','gafd','753498','9840404887','ksafk@gmail.com'),('fwe43','fdggf','mjfh','xcv','2020-12-09','Female','B -ve','2020-12-11','GATE','M.TECH','CE','safsgrge','fddf','vddf','45646','867678768','khjsfd@yahoo.com');
/*!40000 ALTER TABLE `stud` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-28 18:06:45
